//
//  ViewController.swift
//  Midterm
//
//  Created by Merissa Smith on 10/29/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    func textFieldShouldReturn(textField: UITextField) -> Bool { textField.resignFirstResponder()
        return true
    }

    @IBOutlet weak var userCommuteTime: UITextField!
    
    @IBOutlet weak var totalCommuteTime: UILabel!
 
    @IBOutlet weak var button: UIButton!
   

    @IBAction func buttonClicked(sender: UIButton) {
    let miles = (userCommuteTime.text as NSString).floatValue
    let totalCommuteTime = miles/20
    }
    
   
    
    
    
   
    
    override func viewDidLoad() {
        userCommuteTime.delegate=self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

