//
//  ViewController.swift
//  lab3
//
//  Created by Merissa Smith on 9/17/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var checkAmount: UITextField!
    @IBOutlet weak var tipPercent: UITextField!
    @IBOutlet weak var numberPpl: UITextField!
    @IBOutlet weak var tip: UILabel!
    @IBOutlet weak var totalAmount: UILabel!
    @IBOutlet weak var owedPerPerson: UILabel!
    

    func textFieldShouldReturn (textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad (){
        checkAmount.delegate=self
        tipPercent.delegate=self
        numberPpl.delegate=self
        super.viewDidLoad()
    }
    
    func updateTotals(){
        let amount = (checkAmount.text as NSString).floatValue
        let pct = (tipPercent.text as NSString).floatValue/100
        let numberOfPeople=numberPpl.text.toInt()
        let tipp=amount*pct
        let total=amount+tipp
        var personTotal: Float = 0.0
        if numberOfPeople != nil {
            if numberOfPeople! > 0 {
            personTotal = total / Float(numberOfPeople!)
        }
            else {
                //UIAlertController
                let alert=UIAlertController(title: "Warning", message: "The number of people must be greter than 0", preferredStyle: UIAlertControllerStyle.Alert)
                let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertActionStyle.Cancel, handler: nil)
                alert.addAction(cancelAction)
                let okAction=UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {
                    action in self.numberPpl.text="1"
                    self.updateTotals()
                })
                alert.addAction(okAction)
                presentViewController(alert, animated: true, completion: nil)
            } //end
        }
        
        var currencyFormatter = NSNumberFormatter ()
        currencyFormatter.numberStyle=NSNumberFormatterStyle.CurrencyStyle
        tip.text=currencyFormatter.stringFromNumber(tipp)
        totalAmount.text=currencyFormatter.stringFromNumber(total)
        owedPerPerson.text=currencyFormatter.stringFromNumber(personTotal)
    }

    func textFieldDidEndEditing(textField: UITextField) {
        updateTotals()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

