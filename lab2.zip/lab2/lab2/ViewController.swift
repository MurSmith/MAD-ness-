//
//  ViewController.swift
//  lab2
//
//  Created by Merissa Smith on 9/10/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var BassHeadImage: UIImageView!
    @IBOutlet weak var tittleLabel: UILabel!
    
    @IBOutlet weak var ImageControl: UISegmentedControl!
    
    @IBOutlet weak var capitalSwitch: UISwitch!
    
    @IBOutlet weak var fontSizeLabel: UILabel!
    
    @IBAction func changeFontSize(sender: UISlider) {
        let fontSize=sender.value//float
        fontSizeLabel.text=String(format: "%.0f", fontSize) //convert float to String
        let fontSizeCGFloat=CGFloat(fontSize) //convert float to CGFloat
        tittleLabel.font=UIFont.systemFontOfSize(fontSizeCGFloat) //create a UIFont object and assign to the font party 
    }
    func updateCaps(){
        if capitalSwitch.on{
            tittleLabel.text=tittleLabel.text?.uppercaseString
        }
        else {
            tittleLabel.text=tittleLabel.text?.lowercaseString
        }
    }
    
    @IBAction func CapFont(sender: AnyObject) {
      updateCaps()
    }
    
    func updateImage(){
        if ImageControl.selectedSegmentIndex==0{
            tittleLabel.text="Freakbeats for the Beatfreaks"
            BassHeadImage.image=UIImage(named: "Freak")
        }
        else if ImageControl.selectedSegmentIndex==1{
            tittleLabel.text="Into the Sun"
            BassHeadImage.image=UIImage(named: "Sun")
        }
    }
    
    @IBAction func changeInfo(sender: AnyObject) {
        updateImage()
        updateCaps()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

