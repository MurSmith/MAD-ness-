//
//  ViewController.swift
//  lab4
//
//  Created by Merissa Smith on 10/6/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var delta = CGPointMake(12,4)
    var personRadius = CGFloat ()
    var timier = NSTimer()
    var translation = CGPointMake(0.0, 0.0)


    @IBAction func sliderMoved(sender: AnyObject) {
     timier.invalidate()
     changeSliderValue()
    }
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var sliderLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    func moveImage() {
        let duration=Double(slider.value)
        UIView.beginAnimations("SStick", context: nil)
        UIView.animateWithDuration(duration, animations:
            {self.imageView.transform=CGAffineTransformMakeTranslation(self.translation.x, self.translation.y)
                self.translation.x += self.delta.x
                self.translation.y += self.delta.y})
            UIView.commitAnimations()
        
        
        if imageView.center.x + translation.x > self.view.bounds.size.width-personRadius || imageView.center.x + translation.x < personRadius{
            delta.x = -delta.x
        }
        if imageView.center.y + translation.y > view.bounds.size.height - personRadius || imageView.center.y + translation.y < personRadius{
            delta.y = -delta.y
        }
        
    }
    
    @IBAction func changeSliderValue() {
        sliderLabel.text=String(format: "%.2f", slider.value)
        timier = NSTimer.scheduledTimerWithTimeInterval(Double(slider.value),target: self, selector: "moveImage", userInfo: nil, repeats: true)
    }

    
    override func viewDidLoad() {
        personRadius=imageView.frame.size.width/2
        changeSliderValue()
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

