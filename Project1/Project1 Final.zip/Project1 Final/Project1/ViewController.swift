//
//  ViewController.swift
//  Project1
//
//  Created by Merissa Smith on 9/18/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//


import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIGestureRecognizerDelegate {
    
    @IBOutlet weak var wedDate: UITextField!
    @IBOutlet weak var wedLocaction: UISegmentedControl!
    @IBOutlet weak var locationImage: UIImageView!
    
    // start connections for flower buttons
    @IBOutlet weak var FLOWERVIEW: UIImageView!
    @IBOutlet weak var roseview: UIImageView!
    @IBOutlet weak var daisyview: UIImageView!
    @IBOutlet weak var pinkview: UIImageView!
    @IBOutlet weak var winterview: UIImageView!
    // end connections for flower buttons
    
    // start connections for dress buttons
    @IBOutlet weak var dress1: UIImageView!
    @IBOutlet weak var dress2: UIImageView!
    @IBOutlet weak var dress3: UIImageView!
    @IBOutlet weak var dress4: UIImageView!
    @IBOutlet weak var DRESSVIEW: UIImageView!
    //end connections for dress buttons
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        wedDate.delegate=self
        super.viewDidLoad()
        
        // start flower image button
        var UITapRecognizer = UITapGestureRecognizer(target: self, action: "tappedImage:")
        UITapRecognizer.delegate = self
        self.roseview.addGestureRecognizer(UITapRecognizer)
        self.roseview.userInteractionEnabled = true
        
        var UITapDaisy = UITapGestureRecognizer(target: self, action: "tappeddaisy:")
        UITapDaisy.delegate = self
        self.daisyview.addGestureRecognizer(UITapDaisy)
        self.daisyview.userInteractionEnabled = true

        var UITapPink = UITapGestureRecognizer(target: self, action: "tappedpink:")
        UITapPink.delegate = self
        self.pinkview.addGestureRecognizer(UITapPink)
        self.pinkview.userInteractionEnabled = true
        
        var UITapWinter = UITapGestureRecognizer(target: self, action: "tappedwinter:")
        UITapWinter.delegate = self
        self.winterview.addGestureRecognizer(UITapWinter)
        self.winterview.userInteractionEnabled = true
        // end flower image button
        
        //start dress image button
        var UITapDress1 = UITapGestureRecognizer(target: self, action: "tappeddress1:")
        UITapDress1.delegate = self
        self.dress1.addGestureRecognizer(UITapDress1)
        self.dress1.userInteractionEnabled = true
        
        var UITapDress2 = UITapGestureRecognizer(target: self, action: "tappeddress2:")
        UITapDress2.delegate = self
        self.dress2.addGestureRecognizer(UITapDress2)
        self.dress2.userInteractionEnabled = true
        
        var UITapDress3 = UITapGestureRecognizer(target: self, action: "tappeddress3:")
        UITapDress3.delegate = self
        self.dress3.addGestureRecognizer(UITapDress3)
        self.dress3.userInteractionEnabled = true
        
        var UITapDress4 = UITapGestureRecognizer(target: self, action: "tappeddress4:")
        UITapDress4.delegate = self
        self.dress4.addGestureRecognizer(UITapDress4)
        self.dress4.userInteractionEnabled = true
        
        // end dress image button
        
    }
    
    // start flower image button print
    func tappedImage(sender: AnyObject) {
        FLOWERVIEW.image=UIImage(named: "WhiteRose")
    }
    
    func tappeddaisy(sender: AnyObject) {
        FLOWERVIEW.image=UIImage(named: "SunFlower")
    }
    
    func tappedpink(sender: AnyObject) {
        FLOWERVIEW.image=UIImage(named: "PinkFlower")
    }
    
    func tappedwinter(sender: AnyObject) {
        FLOWERVIEW.image=UIImage(named: "WinterFlower")
    }
    // end flower image button print
    
    
    //start dress image button
    func tappeddress1(sender: AnyObject) {
        DRESSVIEW.image=UIImage(named: "BellaDress")
    }
    
    func tappeddress2(sender: AnyObject) {
        DRESSVIEW.image=UIImage(named: "MermaidDress")
    }
    
    func tappeddress3(sender: AnyObject) {
        DRESSVIEW.image=UIImage(named: "LaceDress")
    }
    
    func tappeddress4(sender: AnyObject) {
        DRESSVIEW.image=UIImage(named: "TrainDress")
    }
    //end dress image button

    
    
    func updateLocation() {
        if wedLocaction.selectedSegmentIndex==0{
            locationImage.image=UIImage (named:"Colorado")
        }
        else if wedLocaction.selectedSegmentIndex==1{
            locationImage.image=UIImage (named:"Oregon")
        }
        else if wedLocaction.selectedSegmentIndex==2{
            locationImage.image=UIImage (named:"Mexico")
        }
          
    }
    
    @IBAction func loco(sender: AnyObject) {
        updateLocation()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

