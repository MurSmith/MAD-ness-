//
//  ViewController.swift
//  Project 2
//
//  Created by Merissa Smith on 10/20/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var eventText: UITextField!
    @IBOutlet weak var dateText: UITextField!
    @IBOutlet weak var timeText: UITextField!
    @IBOutlet weak var detailsText: UITextField!
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "createFlyer"{
            var scene2: Scene2ViewController =
            segue.destinationViewController as! Scene2ViewController
            if eventText.text.isEmpty == false{
                scene2.usercreate.eventName=eventText.text
            }
            if dateText.text.isEmpty == false{
                scene2.usercreate.eventDate=dateText.text
            }
            if timeText.text.isEmpty == false{
                scene2.usercreate.eventTime=timeText.text
            }
            if detailsText.text.isEmpty == false{
                scene2.usercreate.eventDetails=detailsText.text
            }
        }

    }
    
    @IBAction func unwindSegue (segue: UIStoryboardSegue) {
        
    }
        
    override func viewDidLoad() {
        eventText.delegate=self
        dateText.delegate=self
        timeText.delegate=self
        detailsText.delegate=self
        super.viewDidLoad()
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

