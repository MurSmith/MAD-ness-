//
//  FlyerData.swift
//  Project 2
//
//  Created by Merissa Smith on 10/26/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import Foundation

class Flyer {
    var eventName : String?
    var eventDate : String?
    var eventTime : String?
    var eventDetails : String?
}
