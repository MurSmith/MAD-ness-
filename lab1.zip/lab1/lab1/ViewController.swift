//
//  ViewController.swift
//  lab1
//
//  Created by Merissa Smith on 9/1/15.
//  Copyright (c) 2015 Merissa Smith. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

   
    @IBOutlet weak var whipImage: UIImageView!
    
    @IBOutlet weak var messageText: UILabel!
    
    @IBAction func chooseWhip(sender: UIButton) {
        if sender.tag == 1{
            whipImage.image=UIImage(named: "Image2")
            messageText.text="Dodge RAM 1500"
            
        }
        if sender.tag==2{
            whipImage.image=UIImage(named: "Image3")
            messageText.text="Goat"
        }
        if sender.tag==3{
            whipImage.image=UIImage(named: "Image4")
            messageText.text="Barbie Jeep"
        }
    }
    @IBOutlet var Image4: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

